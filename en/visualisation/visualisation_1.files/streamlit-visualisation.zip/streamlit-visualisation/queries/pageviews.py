from utils.load_data import get_data


def page_views():
    page_views = get_data("queries/pageviews.sql")
    return page_views


def filter_page_views(page_views, start_date=None, end_date=None):
    if start_date:
        page_views = page_views[page_views["START_TSTAMP"].dt.date >= start_date]

    if end_date:
        page_views = page_views[page_views["START_TSTAMP"].dt.date <= end_date]
    return page_views


def top_pages(page_views):
    top_pages = (
        page_views.groupby("PAGE_TITLE", as_index=False)
        .count()
        .sort_values(by="PAGE_VIEW_ID", ascending=False)
    )
    top_pages = top_pages.reset_index(drop=True)
    top_pages = top_pages.rename(
        columns={"PAGE_TITLE": "Page Title", "PAGE_VIEW_ID": "Pageviews"}
    )
    return top_pages[["Page Title", "Pageviews"]][:8]
