import streamlit as st
import pandas as pd
import snowflake.connector

WAREHOUSE = 'snowflake'


@st.cache
def load_data(csv, nrows=None):
    data = pd.read_csv(csv, nrows=nrows)
    return data


def get_data_from_snowflake(filename):
    db_creds = st.secrets['snowflake']
    cnx = snowflake.connector.connect(
        user=db_creds['user'],
        password=db_creds['password'],
        account=db_creds['account'],
        database=db_creds['database']
    )

    cs = cnx.cursor()
    print('Connected to Snowflake')
    with open(filename, 'r') as f:
        query = f.read()

    try:
        cs.execute(query)
        column_names = [desc[0] for desc in cs.description]
        df = pd.DataFrame(cs.fetchall(), columns=column_names)
    finally:
        cs.close()
    cnx.close()
    return df


@st.cache
def get_data(query):
    if WAREHOUSE == 'snowflake':
        df = get_data_from_snowflake(query)

    return df
