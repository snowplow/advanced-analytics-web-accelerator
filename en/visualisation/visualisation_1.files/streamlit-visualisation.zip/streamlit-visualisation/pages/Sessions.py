import streamlit as st
import queries.sessions as s
import queries.pageviews as pv
import plotly.graph_objects as go
from datetime import timedelta, date

st.set_page_config(layout="wide", page_title="Sessions")

st.title("Sessions Overview")
data_load_state = st.text("Loading data...")
session_data = s.web_sessions()
pageview_data = pv.page_views()
data_load_state.text("")


today = date.today()
last_month = today - timedelta(days=30)

try:
    start_d, end_d = st.date_input("Date range", value=(last_month, today))
    start_d_lm = start_d - timedelta(days=30)
    end_d_lm = end_d - timedelta(days=30)

except ValueError as e:
    start_d = last_month
    end_d = today
    start_d_lm = start_d - timedelta(days=30)
    end_d_lm = end_d - timedelta(days=30)

filtered_session_data = s.filter_web_sessions(session_data, start_d, end_d)
filtered_session_data_lm = s.filter_web_sessions(session_data, start_d_lm, end_d_lm)

filtered_pageview_data = pv.filter_page_views(pageview_data, start_d, end_d)


col1, col2, col3, col4 = st.columns([1, 1, 1, 1])

with col1:
    total_pageviews_by_day = s.total_pageviews_by_day(filtered_session_data)

    total_pageviews = s.total_pageviews(filtered_session_data)
    total_pageviews_lm = s.total_pageviews(filtered_session_data_lm)

    total_page_views_var = (total_pageviews - total_pageviews_lm) / total_pageviews

    st.metric(
        value="{0:,.0f}".format(total_pageviews),
        delta="{0:.2%}".format(total_page_views_var),
        label="TOTAL PAGEVIEWS",
    )

    fig = go.Figure(
        [
            go.Scatter(
                x=total_pageviews_by_day["Day"],
                y=total_pageviews_by_day["PAGE_VIEWS"],
                fill="tozeroy",
            )
        ]
    )

    fig.update_layout(
        height=300,
        width=700,
        margin={"l": 20, "r": 20, "t": 0, "b": 0},
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )
    fig.update_layout(xaxis=dict(tickformat="%d/%m"))

    st.plotly_chart(fig, use_container_width=True)


with col2:
    sessions_by_day = s.total_sessions_by_day(filtered_session_data)

    total_sessions = s.total_sessions(filtered_session_data)
    total_sessions_lm = s.total_sessions(filtered_session_data_lm)

    total_sessions_var = (total_sessions - total_sessions_lm) / total_sessions

    st.metric(
        value="{0:,.0f}".format(total_sessions),
        delta="{0:.2%}".format(total_sessions_var),
        label="TOTAL SESSIONS",
    )
    fig = go.Figure(
        [go.Bar(x=sessions_by_day["Day"], y=sessions_by_day["START_TSTAMP"])]
    )

    fig.update_layout(
        height=300,
        width=700,
        margin={"l": 20, "r": 20, "t": 0, "b": 0},
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )

    fig.update_layout(xaxis=dict(tickformat="%d/%m"))

    st.plotly_chart(fig, use_container_width=True)


with col3:
    bounce_by_day = s.bounce_rate_by_day(filtered_session_data)

    bounce_rate = s.bounce_rate(filtered_session_data)
    bounce_rate_lm = s.bounce_rate(filtered_session_data_lm)

    bounce_rate_var = (bounce_rate - bounce_rate_lm) / bounce_rate

    st.metric(
        value=str(bounce_rate) + "%",
        delta="{0:.2%}".format(bounce_rate_var),
        delta_color="inverse",
        label="BOUNCE RATE",
    )
    fig = go.Figure(
        [
            go.Scatter(
                x=bounce_by_day["Day"], y=bounce_by_day["bounce_rate"], fill="tozeroy"
            )
        ]
    )

    fig.update_layout(
        height=300,
        width=700,
        margin={"l": 20, "r": 20, "t": 0, "b": 0},
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )
    fig.update_layout(xaxis=dict(tickformat="%d/%m"))

    st.plotly_chart(fig, use_container_width=True)


with col4:
    session_len_by_day = s.avg_session_len_by_day(filtered_session_data)

    session_len = s.avg_session_len(filtered_session_data)
    session_len_lm = s.avg_session_len(filtered_session_data_lm)

    session_len_var = (session_len - session_len_lm) / session_len

    st.metric(
        value=str(session_len).split(".")[0]
        + "m"
        + str(session_len).split(".")[1]
        + "s",
        delta="{0:.2%}".format(session_len_var),
        label="AVERAGE SESSION LENGTH",
    )

    fig = go.Figure(
        [go.Bar(x=session_len_by_day["Day"], y=session_len_by_day["ENGAGED_TIME_IN_S"])]
    )

    fig.update_layout(
        height=300,
        width=700,
        margin={"l": 20, "r": 20, "t": 0, "b": 0},
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )

    fig.update_layout(xaxis=dict(tickformat="%d/%m"))
    st.plotly_chart(fig, use_container_width=True)

st.markdown("***")


col1, col2 = st.columns([1, 1])

with col1:
    st.write("SESSIONS BY LOCATION")
    countries = s.sessions_by_country(filtered_session_data)
    fig = go.Figure(
        data=go.Choropleth(
            locations=countries["ISO_3"],
            z=countries["APP_ID"],
            colorscale="Blues",
            showscale=False,
        )
    )

    fig.update_geos(
        visible=False,
        resolution=50,
        showcountries=True,
        countrycolor="LightGrey",
    )
    fig.update_layout(showlegend=False)

    fig.update_layout(
        height=300,
        width=500,
        margin={"l": 20, "r": 20, "t": 0, "b": 0},
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )

    st.plotly_chart(fig, use_container_width=True)

with col2:

    page_views = pv.top_pages(filtered_pageview_data)

    st.write("TOP PAGES (PAGEVIEWS)")
    fig = go.Figure(
        data=[
            go.Table(
                header=dict(values=["", ""], line_color="white", fill_color="white"),
                cells=dict(
                    values=[page_views["Page Title"], page_views["Pageviews"]],
                    align="left",
                    line_color=["white"],
                    fill_color=["white"],
                ),
            )
        ]
    )
    fig.update_layout(
        height=300,
        width=900,
        margin={"l": 20, "r": 20, "t": 0, "b": 0},
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
    )

    st.plotly_chart(fig, use_container_width=False)
