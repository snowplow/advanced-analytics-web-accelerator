# import streamlit as st
from itertools import count
from utils.load_data import get_data

# import pandas as pd
# import numpy as np
# import plotly.graph_objects as go

# import urllib.request
# import json

import streamlit as st


def main():
    st.set_page_config(layout="wide")
    st.title("Advanced Analytics for Web")


if __name__ == "__main__":
    main()
