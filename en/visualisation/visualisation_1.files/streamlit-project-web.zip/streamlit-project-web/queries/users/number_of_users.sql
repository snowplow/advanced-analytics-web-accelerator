select count(1) as number_of_users
from YOUR_SCHEMA.snowplow_web_users
where START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
