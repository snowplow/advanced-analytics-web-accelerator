select geo_country, count(1) as number_of_sessions
from YOUR_SCHEMA.snowplow_web_sessions
-- WHERE START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
and geo_country is not null
group by 1
order by 2 desc