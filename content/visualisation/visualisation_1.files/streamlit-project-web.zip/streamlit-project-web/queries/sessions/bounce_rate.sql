WITH single_pageviews as
    (SELECT DOMAIN_SESSIONID, count(1) AS single_pageviews
    FROM dbt_emiel_derived.snowplow_web_sessions
    WHERE START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
    AND PAGE_VIEWS = 1
    GROUP BY DOMAIN_SESSIONID),

total_pageviews as 
    (
        SELECT DOMAIN_SESSIONID, sum(PAGE_VIEWS)  as total_pageviews
        FROM  dbt_emiel_derived.snowplow_web_sessions
        WHERE START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
        GROUP BY DOMAIN_SESSIONID
    )

select sum(single_pageviews.single_pageviews) / sum(total_pageviews.total_pageviews) AS BounceRate
from  total_pageviews
left join single_pageviews
on total_pageviews.DOMAIN_SESSIONID = single_pageviews.DOMAIN_SESSIONID 

