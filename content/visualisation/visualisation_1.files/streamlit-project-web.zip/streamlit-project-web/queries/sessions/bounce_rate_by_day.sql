WITH 
single_pageviews as
    (
        SELECT date(START_TSTAMP) as Date, count(1) AS single_pageviews
        FROM YOUR_SCHEMA.snowplow_web_sessions
        -- WHERE START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
        AND PAGE_VIEWS = 1
        GROUP BY  date(START_TSTAMP)
    ),

total_pageviews as 
    (
        SELECT date(START_TSTAMP) as Date,  sum(PAGE_VIEWS) AS total_pageviews
        FROM YOUR_SCHEMA.snowplow_web_sessions
        -- WHERE START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
        GROUP BY  date(START_TSTAMP)
    )

SELECT total_pageviews.Date, sum(single_pageviews.single_pageviews) / sum(total_pageviews.total_pageviews) as BounceRate
FROM total_pageviews
join single_pageviews
ON single_pageviews.Date = total_pageviews.Date
group by total_pageviews.Date
order by total_pageviews.Date

