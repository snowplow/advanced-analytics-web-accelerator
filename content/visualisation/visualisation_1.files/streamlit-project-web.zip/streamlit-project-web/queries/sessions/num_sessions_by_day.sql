SELECT date(START_TSTAMP) as Date, count(1) AS number_of_sessions
FROM dbt_emiel_derived.snowplow_web_sessions
WHERE START_TSTAMP BETWEEN DATEADD(day, -7, GETDATE()) AND  DATEADD(day, -1, GETDATE())
group BY date(START_TSTAMP)
order BY date(START_TSTAMP)