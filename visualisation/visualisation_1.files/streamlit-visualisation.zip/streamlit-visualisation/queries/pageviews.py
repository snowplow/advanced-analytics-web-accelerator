from json import load
import pandas as pd
import numpy as np
from utils.load_data import load_data, get_data


def page_views():
    # page_views = load_data(
    #     "/Users/jackkeene/Documents/Work/js-projects/streamlit-example-project/utils/sp_webpage_views.csv")
    page_views = get_data("../streamlit-example-project/queries/pageviews.sql")
    return page_views


def filter_page_views(page_views, start_date=None, end_date=None):
    if start_date:
        page_views = page_views[page_views["START_TSTAMP"].dt.date >= start_date]

    if end_date:
        page_views = page_views[page_views["START_TSTAMP"].dt.date <= end_date]
    return page_views


def top_pages(page_views):
    top_pages = (
        page_views.groupby("PAGE_TITLE", as_index=False)
        .count()
        .sort_values(by="PAGE_VIEW_ID", ascending=False)
    )
    top_pages = top_pages.reset_index(drop=True)
    top_pages = top_pages.rename(
        columns={"PAGE_TITLE": "Page Title", "PAGE_VIEW_ID": "Pageviews"}
    )
    # print(top_pages)
    return top_pages[["Page Title", "Pageviews"]][:8]
