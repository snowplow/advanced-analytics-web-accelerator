from json import load
import pandas as pd
import numpy as np
from utils.load_data import load_data, get_data
import urllib.request
import json


def web_sessions():
    webpage_sessions = get_data(
        '../streamlit-example-project/queries/sessions.sql')
    return webpage_sessions


def filter_web_sessions(webpage_sessions, start_date=None, end_date=None):
    if start_date:
        webpage_sessions = webpage_sessions[webpage_sessions['START_TSTAMP'].dt.date >= start_date]

    if end_date:
        webpage_sessions = webpage_sessions[webpage_sessions['START_TSTAMP'].dt.date <= end_date]
    return webpage_sessions


def unique_visits(webpage_sessions):
    return len(webpage_sessions)


def unique_visits_hist(webpage_sessions):
    hist_values = np.histogram(
        pd.to_datetime(webpage_sessions['START_TSTAMP']).dt.day, bins=24, range=(0, 24))[0]
    return hist_values


def total_pageviews(webpage_sessions):
    return webpage_sessions['PAGE_VIEWS'].sum()


def total_pageviews_by_day(webpage_sessions):
    hist = webpage_sessions[['START_TSTAMP', 'PAGE_VIEWS']].copy()
    hist['Day'] = pd.to_datetime(hist['START_TSTAMP']).dt.date

    hist = hist.groupby(
        'Day', as_index=False).sum().sort_values(by='Day', ascending=True)
    return hist


def average_page_views(webpage_sessions):
    return float('{0:,.2f}'.format((total_visits(webpage_sessions)/unique_visits(webpage_sessions))))


def total_sessions(webpage_sessions):
    return len(webpage_sessions)


def total_sessions_by_day(webpage_sessions):
    hist = webpage_sessions[['START_TSTAMP']].copy()
    hist['Day'] = pd.to_datetime(hist['START_TSTAMP']).dt.date

    hist = hist.groupby(
        'Day', as_index=False).count().sort_values(by='Day', ascending=True)
    return hist


def avg_session_len(webpage_sessions):
    return float('{0:,.2f}'.format((webpage_sessions['ENGAGED_TIME_IN_S'].sum()/total_sessions(webpage_sessions))/60))


def avg_session_len_by_day(webpage_sessions):
    hist = webpage_sessions[['START_TSTAMP', 'ENGAGED_TIME_IN_S']].copy()
    hist['Day'] = pd.to_datetime(hist['START_TSTAMP']).dt.date

    hist = hist.groupby(
        'Day', as_index=False).mean().sort_values(by='Day', ascending=True)

    hist['ENGAGED_TIME_IN_S'] = hist['ENGAGED_TIME_IN_S']/60
    return hist


def bounce_rate(webpage_sessions):
    single_page_visits = len(
        webpage_sessions[webpage_sessions['PAGE_VIEWS'] == 1]['PAGE_VIEWS'])
    return float('{0:,.2f}'.format(100*single_page_visits/total_pageviews(webpage_sessions)))


def bounce_rate_by_day(webpage_sessions):
    hist = webpage_sessions[['START_TSTAMP', 'PAGE_VIEWS']].copy()
    hist['Bounce'] = 0
    hist.loc[hist['PAGE_VIEWS'] == 1, 'Bounce'] = 1

    hist['Day'] = pd.to_datetime(hist['START_TSTAMP']).dt.date

    hist = hist.groupby(
        'Day', as_index=False).sum().sort_values(by='Day', ascending=True)

    hist['bounce_rate'] = hist['Bounce']/hist['PAGE_VIEWS']
    return hist


def sessions_by_country(web_sessions):
    url = urllib.request.urlopen("http://country.io/iso3.json")
    country_codes = json.loads(url.read().decode())
    countries = web_sessions.groupby(
        ['GEO_COUNTRY'], as_index=False).count()

    countries['ISO_3'] = countries['GEO_COUNTRY'].map(country_codes)

    return countries[['ISO_3', 'APP_ID']]
